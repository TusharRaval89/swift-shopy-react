import React from "react";
import { Link } from "react-router-dom";
import { MdAccountCircle } from "react-icons/md";

function Signup() {
  return (
    <>
      <div className="form-container">
        <div className="form-content">
          <div className="text-center fs-1">
            <MdAccountCircle />
          </div>
          <div>
            <h2 className="text-center">Create Account </h2>
          </div>
          <div className="mt-3">
            <div className="head-cnt">Your First Name</div>
            <input type="text" placeholder="First Name" />
          </div>
          <div className="mt-3">
            <div className="head-cnt">Your Last Name</div>
            <input type="text" placeholder="Last Name" />
          </div>
          <div className="mt-3">
            <div className="head-cnt">Email</div>
            <input type="text" placeholder="Email" />
          </div>
          <div className="mt-3">
            <div className="head-cnt">Password</div>
            <input type="text" placeholder="Password" />
          </div>
          <div className="mt-3 ">
            <input
              type="button"
              value="signup"
              className="button"
              style={{ color: "white" }}
            />
          </div>
          <div className="mt-3 ">
            <p className="text-center">
              Already have an account?{" "}
              <Link to="/login">
                
                Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Signup;
