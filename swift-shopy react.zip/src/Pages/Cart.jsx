import React, { useState } from "react";
import { FaStar } from "react-icons/fa6";
import { IoIosArrowDown } from "react-icons/io";
import { Link } from "react-router-dom";
import Tshirts from "../assets/images/amiri tshirts.jpg";
import Truck from "../assets/images/truck.jpg";
import Ring from "../assets/images/ring.jpg";
import cricketKit from "../assets/images/kit.jpg";
import rolex from "../assets/images/rolex watch.jpg";
import iphone from "../assets/images/iphone.jpg";
import { PiShoppingCartBold } from "react-icons/pi";

const Cart = () => {
  const [allProductData, setallProductData] = useState([
    {
      id: 1,
      title: "I Phone 16 pro max",
      image: iphone,
      category: "electronic",
      brand: "Apple",
      rating: "4.5",
      amount: "89,999",
      discount_amount: "99,9999",
      discount_percentage: "29%",
      rating_count: "25002",
      last_purchase_count: "2.2k",
    },
    {
      id: 2,
      title: "Allen Solly",
      image: Tshirts,
      category: "clothes",
      brand: "Amiri",
      rating: "4.2",
      amount: "15,000",
      discount_amount: "20,000",
      discount_percentage: "30%",
      rating_count: "12345",
      last_purchase_count: "1.7k",
    },
    {
      id: 3,
      title: "Heavy Truck",
      image: Truck,
      category: "toys",
      brand: "cello",
      rating: "3.9",
      amount: "12,000",
      discount_amount: "15,000",
      discount_percentage: "50%",
      rating_count: "45325",
      last_purchase_count: "2.9k",
    },
    {
      id: 4,
      title: "Elite Silver Chunky Rings",
      image: Ring,
      category: "jewellary",
      brand: "prada",
      rating: "4.7",
      amount: "76,500",
      discount_amount: "85,500",
      discount_percentage: "15%",
      rating_count: "34231",
      last_purchase_count: "1.5k",
    },
    {
      id: 5,
      title: "TASCO SPORTS Grand Edition",
      image: cricketKit,
      category: "sports",
      brand: "Reebook",
      rating: "3.2",
      amount: "22,350",
      discount_amount: "25,000",
      discount_percentage: "9%",
      rating_count: "34235",
      last_purchase_count: "2.2k",
    },
    {
      id: 6,
      title: "Mechanical Men's Watch",
      image: rolex,
      category: "Accessory",
      brand: "Rolex",
      rating: "4.9",
      amount: "90,000",
      discount_amount: "95,000",
      discount_percentage: "10%",
      rating_count: "67453",
      last_purchase_count: "1.2k",
    },
  ]);
  return (
    <>
   
      <div className="container-fluid">
        <div className="container">
          <div className="row g-4 d-flex flex-wrap mt-3">
            {allProductData.map((card, index) => (
              <div className="col-md-3 col-sm-6 col-12" key={index}>
                <Link to={`/product?id=${card.id}`}>
                  <div className="card h-100 d-flex flex-column">
                    <img
                      src={card.image}
                      className="card-img-top container-fluid"
                      alt={card.title}
                    />
                    <div className="card-body d-flex flex-column align-items-center">
                      <h5 className="card-title fs-4 text-center fw-bold clamped-text" title={card.title}>
                        {card.title}
                      </h5>
                      <div className="d-flex justify-content-center align-items-center">
                        <span className="fs-6 d-flex align-items-center">
                          {[...Array(5)].map((_, i) => (
                            <FaStar key={i} className="ms-1 text-warning" />
                          ))}
                          <IoIosArrowDown className="ms-1" />
                          <p className="fw-bold fs-6 text-center ms-1 pt-3">
                            {card.rating_count}
                          </p>
                        </span>
                      </div>
                      <div className="text-center">
                        {card.last_purchase_count}+ bought in last month
                      </div>
                      <p className="card-text  text-center fw-bold">
                        <span className="ms-1  text-danger">
                          ({card.discount_percentage} off)
                        </span>
                        <span className="ms-3">
                          <sup>₹</sup>
                        </span>
                        <span className="fs-2">{card.amount}</span>
                        <br />
                        <span className="ms-1 fs-6 text-muted strike">
                          M.R.P: ₹{card.discount_amount}
                        </span>
                        <br />
                      </p>

                      <div className="btn-grp d-flex flex-column align-items-center gap-3 w-100">
                        <button className="common-btn2 btn-padding w-75 fs-6">
                          BUY NOW
                        </button>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    
    </>
  );
};

export default Cart;
