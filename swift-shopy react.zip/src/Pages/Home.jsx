import React from "react";
import AllProduct from "../Components/AllProduct";

const Home = () => {
  return (
    <div>
      <AllProduct />
    </div>
  );
};

export default Home;
