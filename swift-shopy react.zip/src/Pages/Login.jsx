import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { MdAccountCircle } from "react-icons/md";

function Login() {

  return (
    <>
      <div className="form-container">
        <div className="form-content">
            <div className="text-center fs-1">
                <MdAccountCircle />
            </div>
          <div>
            <h2 className="text-center">Login </h2>
          </div>
         
          <div className="mt-3">
          <div className="head-cnt">Email</div>
            <input type="text" placeholder="Email" />
          </div>
          <div className="mt-3">
          <div className="head-cnt">Password</div>
            <input type="text" placeholder="Password" />
          </div>
          <div className="mt-3 ">
            <input type="button" value="Login" className="button" style={{color:"white"}}/> 
          </div>
          <div className="mt-3 ">
            <p className="text-center">
            Don't have an account? <Link to="/signup">  Signup</Link>
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
